package pl.sda.zajecia4.homework.task3;

public class Main {
    public static void main(String[] args) {
        Board b1 = new Board(10,10);
        Board b2 = new Board(10,10);
        Ships gameOne = new Ships(b1,b2);

        gameOne.addShip(b1,4,4,4,4);
        gameOne.addShip(b2,1,3,1,5);
        gameOne.printBoards();

    }
}
// dlaczego dodaje statki na obu playerach
// dodaj liczenie punktow za zetsrzelenia