package pl.sda.zajecia4.homework.task3;

public class Ships {
    private Board playerOne;
    private Board playerTwo;

    public Ships(Board playerOne, Board playerTwo) {
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
    }
    public void addShip(Board player, int xBeginingCoordinates, int yBeginingCoordinates, int xEndCoordinates, int yEndCoordinates){
        player.addShip(xBeginingCoordinates,yBeginingCoordinates,xEndCoordinates,yEndCoordinates);
    }
    public void shoot(Board player,int x, int y ){
        if(player.shot(x,y)){
            System.out.println("Trafiony!");
        }else {
            System.out.println("Pudło!");
        }
    }
    public void printBoard(Board player){
        player.printBoard();
    }
    public void printBoards(){
        System.out.println("Plansza pierwszego gracza: ");
        playerOne.printBoard();
        System.out.println("\nPlansza drugiego gracza: ");
        playerTwo.printBoard();
    }
}
